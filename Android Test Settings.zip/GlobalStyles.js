/* fonts */
export const FontFamily = {
  interRegular: "Inter_regular",
  alegreyaSansMedium: "Alegreya Sans_medium",
  alegreyaSansBold: "Alegreya Sans_bold",
  alataRegular: "Alata_regular",
  heading1Medium: "Montserrat_regular",
  defaultSizeBody: "SF Pro Text_regular",
  sFProDisplayMedium: "SF Pro Display_medium",
  montserratLight: "Montserrat_light",
  montserratSemibold: "Montserrat_semibold",
  alegreyaSansRegular: "Alegreya Sans_regular",
  alegreyaSansThin: "Alegreya Sans_thin",
};
/* font sizes */
export const FontSize = {
  size_xs: 12,
  heading1Medium_size: 24,
  size_xl: 20,
  size_sm: 14,
  defaultSizeBody_size: 17,
  size_mid_6: 18,
  size_4xs_1: 8,
  size_35xl_3: 54,
  size_4xs_2: 8,
  size_mid_7: 18,
  size_13xl: 32,
  size_5xs_1: 7,
  size_6xs: 7,
  size_7xs: 6,
  size_2xs: 11,
  size_5xs: 8,
  size_base: 16,
};
/* Colors */
export const Color = {
  darkslateblue: "#18234f",
  gray_100: "#332821",
  gray_200: "rgba(255, 255, 255, 0)",
  systemMaterialsSMLThick: "rgba(250, 250, 250, 0.93)",
  gainsboro_100: "#dedede",
  gainsboro_200: "#d9d9d9",
  black: "#000",
  white: "#fff",
  labelColorsLCLSecondary: "rgba(60, 60, 67, 0.6)",
  lightskyblue: "#6fb1ee",
};
/* border radiuses */
export const Border = {
  br_4xl: 23,
  br_4xs: 9,
  br_2xs_9: 11,
  br_mid: 17,
  br_5xs_1: 7,
  br_7xs: 6,
};
