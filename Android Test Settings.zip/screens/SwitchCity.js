import * as React from "react";
import { StyleSheet, View, Text, Image } from "react-native";
import { Color, FontFamily, Border, FontSize } from "../GlobalStyles";

const SwitchCity = () => {
  return (
    <View style={styles.switchCity}>
      <View style={[styles.switchCityChild, styles.cityShadowBox]} />
      <Text style={styles.myLocation}>My Location</Text>
      <Image
        style={[styles.locationOnIcon, styles.locationOnIconPosition]}
        resizeMode="cover"
        source={require("../assets/location-on.png")}
      />
      <View style={[styles.bangkok, styles.cityLayout]}>
        <View style={[styles.city, styles.cityChildPosition]}>
          <View style={[styles.cityChild, styles.cityChildPosition]} />
          <Text style={[styles.cityName, styles.cloudyPosition]}>Bangkok</Text>
          <Text style={[styles.cloudy, styles.cloudyTypo]}>Cloudy</Text>
          <Text style={[styles.text, styles.textFlexBox]}>4°</Text>
        </View>
        <Text style={[styles.cloudy1, styles.cloudy1Position]}>Cloudy</Text>
        <Text style={[styles.bangkok1, styles.cloudy1Position]}>Bangkok</Text>
        <Image
          style={[styles.bangkokChild, styles.bangkokChildLayout]}
          resizeMode="cover"
          source={require("../assets/ellipse-11.png")}
        />
      </View>
      <View style={[styles.bangkok2, styles.cityLayout]}>
        <View style={[styles.city, styles.cityChildPosition]}>
          <View style={[styles.cityChild, styles.cityChildPosition]} />
          <Text style={[styles.cityName, styles.cloudyPosition]}>Bangkok</Text>
          <Text style={[styles.cloudy, styles.cloudyTypo]}>Cloudy</Text>
          <Text style={[styles.text, styles.textFlexBox]}>4°</Text>
        </View>
        <Image
          style={[styles.hamburgerMenuIcon, styles.hamburgerIconLayout]}
          resizeMode="cover"
          source={require("../assets/hamburger-menu.png")}
        />
        <Text style={[styles.cloudy1, styles.cloudy1Position]}>Cloudy</Text>
        <Text style={[styles.bangkok1, styles.cloudy1Position]}>Stockholm</Text>
      </View>
      <Image
        style={[styles.hamburgerMenuIcon1, styles.hamburgerIconLayout]}
        resizeMode="cover"
        source={require("../assets/hamburger-menu.png")}
      />
      <Image
        style={[styles.switchCityItem, styles.bangkokChildLayout]}
        resizeMode="cover"
        source={require("../assets/ellipse-11.png")}
      />
      <Image
        style={styles.arrowIcon}
        resizeMode="cover"
        source={require("../assets/arrow1.png")}
      />
      <View style={[styles.searchbar, styles.cityShadowBox]}>
        <View style={styles.content}>
          <View style={styles.magnifyingglass}>
            <Text style={[styles.magnifyingglass1, styles.textFlexBox]}>􀊫</Text>
          </View>
          <Text style={styles.placeholderLabel}>Search</Text>
        </View>
      </View>
      <View style={[styles.editCity, styles.editLayout]}>
        <View style={[styles.editCityChild, styles.editLayout]} />
        <Text style={styles.cancel}>Cancel</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  cityShadowBox: {
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  locationOnIconPosition: {
    top: 200,
    position: "absolute",
  },
  cityLayout: {
    height: 91,
    width: 310,
    position: "absolute",
  },
  cityChildPosition: {
    left: 0,
    top: 0,
  },
  cloudyPosition: {
    display: "none",
    left: 18,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  cloudyTypo: {
    fontFamily: FontFamily.montserratLight,
    fontWeight: "300",
    fontSize: 8,
  },
  textFlexBox: {
    justifyContent: "center",
    alignItems: "center",
    textAlign: "center",
    position: "absolute",
  },
  cloudy1Position: {
    left: 43,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  bangkokChildLayout: {
    height: 19,
    width: 19,
    position: "absolute",
  },
  hamburgerIconLayout: {
    height: 15,
    width: 21,
    position: "absolute",
    overflow: "hidden",
  },
  editLayout: {
    height: 31,
    width: 116,
    position: "absolute",
  },
  switchCityChild: {
    left: 16,
    borderRadius: Border.br_mid,
    width: 329,
    height: 39,
    backgroundColor: Color.white,
    top: 200,
    position: "absolute",
  },
  myLocation: {
    top: 208,
    left: 29,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.heading1Medium,
    fontSize: 18,
    position: "absolute",
  },
  locationOnIcon: {
    left: 293,
    width: 38,
    height: 38,
    overflow: "hidden",
  },
  cityChild: {
    backgroundColor: Color.lightskyblue,
    height: 91,
    width: 310,
    position: "absolute",
  },
  cityName: {
    top: 23,
    fontFamily: FontFamily.heading1Medium,
    fontSize: 18,
  },
  cloudy: {
    top: 46,
    display: "none",
    left: 18,
    textAlign: "left",
    color: Color.black,
    position: "absolute",
  },
  text: {
    top: 12,
    left: 243,
    fontSize: 54,
    fontWeight: "600",
    fontFamily: FontFamily.montserratSemibold,
    width: 58,
    height: 67,
    color: Color.white,
    justifyContent: "center",
    display: "none",
  },
  city: {
    borderRadius: 11,
    height: 91,
    width: 310,
    position: "absolute",
    backgroundColor: Color.white,
    overflow: "hidden",
  },
  cloudy1: {
    top: 50,
    fontFamily: FontFamily.montserratLight,
    fontWeight: "300",
    fontSize: 8,
  },
  bangkok1: {
    top: 21,
    fontFamily: FontFamily.heading1Medium,
    fontSize: 18,
  },
  bangkokChild: {
    top: 35,
    left: 266,
  },
  bangkok: {
    top: 387,
    left: 25,
    width: 310,
  },
  hamburgerMenuIcon: {
    top: 38,
    left: 12,
  },
  bangkok2: {
    top: 277,
    left: 25,
    width: 310,
  },
  hamburgerMenuIcon1: {
    top: 422,
    left: 37,
  },
  switchCityItem: {
    top: 313,
    left: 291,
  },
  arrowIcon: {
    top: 29,
    left: 6,
    width: 49,
    height: 40,
    position: "absolute",
    overflow: "hidden",
  },
  magnifyingglass1: {
    height: "100%",
    top: "0%",
    left: "0%",
    lineHeight: 50,
    fontWeight: "500",
    fontFamily: FontFamily.sFProDisplayMedium,
    display: "flex",
    color: Color.labelColorsLCLSecondary,
    justifyContent: "center",
    fontSize: 18,
    width: "100%",
  },
  magnifyingglass: {
    width: 28,
    height: 28,
    overflow: "hidden",
  },
  placeholderLabel: {
    fontSize: FontSize.defaultSizeBody_size,
    letterSpacing: 0,
    lineHeight: 22,
    fontFamily: FontFamily.defaultSizeBody,
    color: Color.labelColorsLCLSecondary,
    textAlign: "left",
    flex: 1,
  },
  content: {
    alignSelf: "stretch",
    borderRadius: 10,
    backgroundColor: Color.systemMaterialsSMLThick,
    height: 36,
    flexDirection: "row",
    padding: 8,
    alignItems: "center",
  },
  searchbar: {
    top: 81,
    left: 30,
    width: 300,
    backgroundColor: Color.white,
    position: "absolute",
  },
  editCityChild: {
    borderRadius: Border.br_4xs,
    backgroundColor: "#e95f67",
    left: 0,
    top: 0,
  },
  cancel: {
    top: 7,
    left: 34,
    fontSize: FontSize.size_sm,
    textAlign: "center",
    color: Color.white,
    fontFamily: FontFamily.heading1Medium,
    position: "absolute",
  },
  editCity: {
    top: 569,
    left: 116,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  switchCity: {
    backgroundColor: Color.gainsboro_100,
    height: 800,
    overflow: "hidden",
    width: "100%",
    flex: 1,
  },
});

export default SwitchCity;
