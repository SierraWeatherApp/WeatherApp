import * as React from "react";
import { Image, StyleSheet, Text, View } from "react-native";
import { Color, FontFamily, FontSize, Border } from "../GlobalStyles";

const ContactUs = () => {
  return (
    <View style={styles.contactUs}>
      <Image
        style={styles.contactUsChild}
        resizeMode="cover"
        source={require("../assets/rectangle-81.png")}
      />
      <Text style={styles.nameXxx}>Name: XXX</Text>
      <Text style={[styles.emailXxx, styles.xxxTypo]}>Email: XXX</Text>
      <Text style={[styles.telXxx, styles.xxxTypo]}>Tel: XXX</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  xxxTypo: {
    width: 138,
    height: 30,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  contactUsChild: {
    top: 45,
    left: 12,
    borderRadius: Border.br_4xl,
    width: 328,
    height: 318,
    position: "absolute",
  },
  nameXxx: {
    top: 70,
    width: 110,
    height: 30,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_xl,
    left: 41,
    position: "absolute",
  },
  emailXxx: {
    top: 123,
    left: 41,
    width: 138,
  },
  telXxx: {
    top: 176,
    left: 38,
  },
  contactUs: {
    backgroundColor: Color.gainsboro_100,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default ContactUs;
