import * as React from "react";
import { Image, StyleSheet, Pressable, Text, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Border, Color, FontSize, FontFamily } from "../GlobalStyles";

const Settings = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.settings, styles.iconLayout]}>
      <Pressable
        style={styles.x}
        onPress={() => navigation.navigate("DayHomePage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/x.png")}
        />
      </Pressable>
      <View style={[styles.vectorParent, styles.frameChildLayout]}>
        <Image
          style={[styles.frameChild, styles.frameLayout2]}
          resizeMode="cover"
          source={require("../assets/rectangle-81.png")}
        />
        <Pressable
          style={[styles.faqFrame, styles.frameLayout1]}
          onPress={() => navigation.navigate("FAQWindow")}
        >
          <Text style={[styles.faq, styles.faqLayout]}>FAQ</Text>
        </Pressable>
        <View style={[styles.recommendationsFrame, styles.frameLayout1]}>
          <Text style={[styles.recommendationsFeedback, styles.faqLayout]}>
            Recommendations feedback
          </Text>
        </View>
        <Pressable
          style={[styles.temperatureFrame, styles.frameLayout]}
          onPress={() => navigation.navigate("ChangeTemperature")}
        >
          <Text
            style={[styles.temperatureCelciusCContainer, styles.resetPosition]}
          >
            <Text style={styles.temperature}>{`Temperature
`}</Text>
            <Text style={styles.celciusC}>{`Celcius C° `}</Text>
          </Text>
        </Pressable>
        <Pressable
          style={[styles.resetFrame, styles.frameLayout1]}
          onPress={() => navigation.navigate("ResetWindow")}
        >
          <Text style={[styles.reset, styles.resetPosition]}>Reset</Text>
        </Pressable>
        <Pressable
          style={[styles.transferFrame, styles.frameLayout1]}
          onPress={() => navigation.navigate("ResetWindow")}
        >
          <Text style={[styles.transferSettings, styles.faqLayout]}>
            Transfer settings
          </Text>
        </Pressable>
        <Pressable
          style={[styles.contanctUsFrame, styles.frameLayout1]}
          onPress={() => navigation.navigate("ContactUs")}
        >
          <Text style={[styles.contactUs, styles.faqLayout]}>Contact us</Text>
        </Pressable>
      </View>
      <View style={[styles.vectorGroup, styles.frameItemLayout]}>
        <Image
          style={[styles.frameItem, styles.frameItemLayout]}
          resizeMode="cover"
          source={require("../assets/rectangle-9.png")}
        />
        <View style={[styles.helpFrame, styles.framePosition]}>
          <Text
            style={[styles.helpSupport, styles.privacyTypo]}
          >{`Help & Support`}</Text>
        </View>
        <View style={[styles.aboutWeatherFrame, styles.frameLayout]}>
          <Text style={[styles.aboutWeatherApp, styles.privacyTypo]}>
            About Weather app
          </Text>
        </View>
        <View style={[styles.privacyFrame, styles.framePosition]}>
          <Text style={[styles.privacy, styles.privacyTypo]}>Privacy</Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    width: "100%",
    overflow: "hidden",
  },
  frameChildLayout: {
    height: 310,
    position: "absolute",
  },
  frameLayout2: {
    borderRadius: Border.br_4xl,
    top: 0,
    left: 0,
    width: 320,
  },
  frameLayout1: {
    height: 50,
    width: 319,
    position: "absolute",
    overflow: "hidden",
  },
  faqLayout: {
    height: 30,
    color: Color.black,
    fontSize: FontSize.size_xl,
  },
  frameLayout: {
    height: 60,
    width: 319,
    top: 0,
    position: "absolute",
    overflow: "hidden",
  },
  resetPosition: {
    top: 16,
    textAlign: "left",
    fontFamily: FontFamily.heading1Medium,
    position: "absolute",
  },
  frameItemLayout: {
    height: 180,
    position: "absolute",
  },
  framePosition: {
    left: -1,
    height: 60,
    width: 319,
    position: "absolute",
    overflow: "hidden",
  },
  privacyTypo: {
    height: 34,
    textAlign: "left",
    color: Color.black,
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_xl,
    position: "absolute",
  },
  icon: {
    height: "100%",
    overflow: "hidden",
  },
  x: {
    left: 320,
    width: 40,
    height: 40,
    top: 6,
    position: "absolute",
  },
  frameChild: {
    height: 310,
    position: "absolute",
  },
  faq: {
    top: 8,
    width: 45,
    textAlign: "left",
    fontFamily: FontFamily.heading1Medium,
    height: 30,
    position: "absolute",
    left: 13,
  },
  faqFrame: {
    top: 210,
    left: 1,
  },
  recommendationsFeedback: {
    top: 4,
    width: 297,
    left: 14,
    textAlign: "left",
    fontFamily: FontFamily.heading1Medium,
    height: 30,
    position: "absolute",
  },
  recommendationsFrame: {
    top: 260,
    left: 0,
  },
  temperature: {
    color: Color.black,
    fontSize: FontSize.size_xl,
  },
  celciusC: {
    fontSize: FontSize.size_sm,
    color: "#2c7900",
  },
  temperatureCelciusCContainer: {
    width: 133,
    height: 48,
    left: 13,
  },
  temperatureFrame: {
    left: 1,
  },
  reset: {
    width: 58,
    left: 14,
    height: 30,
    color: Color.black,
    fontSize: FontSize.size_xl,
  },
  resetFrame: {
    top: 110,
    left: 0,
  },
  transferSettings: {
    top: 20,
    right: 1,
    width: 305,
    textAlign: "left",
    fontFamily: FontFamily.heading1Medium,
    height: 30,
    position: "absolute",
  },
  transferFrame: {
    top: 60,
    left: 1,
  },
  contactUs: {
    top: 12,
    width: 110,
    textAlign: "left",
    fontFamily: FontFamily.heading1Medium,
    height: 30,
    position: "absolute",
    left: 13,
  },
  contanctUsFrame: {
    top: 160,
    left: 1,
  },
  vectorParent: {
    top: 46,
    left: 20,
    width: 320,
    height: 310,
    overflow: "hidden",
  },
  frameItem: {
    borderRadius: Border.br_4xl,
    top: 0,
    left: 0,
    width: 320,
  },
  helpSupport: {
    left: 15,
    width: 156,
    top: 6,
  },
  helpFrame: {
    top: 120,
  },
  aboutWeatherApp: {
    top: 19,
    width: 202,
    left: 13,
  },
  aboutWeatherFrame: {
    left: 0,
  },
  privacy: {
    top: 13,
    width: 73,
    left: 14,
  },
  privacyFrame: {
    top: 60,
  },
  vectorGroup: {
    top: 395,
    left: 21,
    width: 318,
    overflow: "hidden",
  },
  settings: {
    backgroundColor: Color.gainsboro_100,
    flex: 1,
    height: 800,
    overflow: "hidden",
  },
});

export default Settings;
