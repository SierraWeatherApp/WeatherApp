/* fonts */
export const FontFamily = {
  heading1Medium: "Montserrat_regular",
  defaultSizeBody: "SF Pro Text_regular",
  sFProDisplayMedium: "SF Pro Display_medium",
  montserratLight: "Montserrat_light",
  montserratSemibold: "Montserrat_semibold",
  montserratBold: "Montserrat_bold",
  metrophobicRegular: "Metrophobic_regular",
  alegreyaSansMedium: "Alegreya Sans_medium",
  alegreyaSansBold: "Alegreya Sans_bold",
  alataRegular: "Alata_regular",
  interRegular: "Inter_regular",
  alegreyaSansRegular: "Alegreya Sans_regular",
  alegreyaSansThin: "Alegreya Sans_thin",
  montserratMedium: "Montserrat_medium",
  montserratAlternatesRegular: "Montserrat Alternates_regular",
};
/* font sizes */
export const FontSize = {
  size_sm: 14,
  defaultSizeBody_size: 17,
  size_mid_6: 18,
  size_4xs_1: 8,
  size_35xl_3: 54,
  size_4xs_2: 8,
  size_mid_7: 18,
  heading1Medium_size: 24,
  size_base: 16,
  size_5xs_1: 7,
  size_mini: 15,
  size_xl: 20,
  size_xs: 12,
  size_6xs: 7,
  size_7xs: 6,
  size_2xs: 11,
  size_5xs: 8,
  size_13xl: 32,
};
/* Colors */
export const Color = {
  gainsboro_100: "#dedede",
  gainsboro_200: "#d9d9d9",
  white: "#fff",
  indianred: "#e95f67",
  gray_100: "#888",
  gray_200: "#332821",
  gray_300: "rgba(255, 255, 255, 0)",
  systemMaterialsSMLThick: "rgba(250, 250, 250, 0.93)",
  labelColorsLCLSecondary: "rgba(60, 60, 67, 0.6)",
  black: "#000",
  lightskyblue: "#6fb1ee",
  red: "#ff0000",
  darkslateblue: "#18234f",
};
/* Paddings */
export const Padding = {
  p_xl: 20,
};
/* border radiuses */
export const Border = {
  br_4xs: 9,
  br_2xs_9: 11,
  br_mid: 17,
  br_4xl: 23,
  br_5xs_1: 7,
  br_7xs: 6,
};
