import * as React from "react";
import { Image, StyleSheet, Pressable, View } from "react-native";
import { useNavigation } from "@react-navigation/native";
import { Color } from "../GlobalStyles";

const FAQWindow = () => {
  const navigation = useNavigation();

  return (
    <View style={[styles.faqWindow, styles.iconLayout]}>
      <Pressable
        style={styles.x}
        onPress={() => navigation.navigate("DayHomePage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/x2.png")}
        />
      </Pressable>
      <View style={styles.faqWindowChild} />
      <Image
        style={styles.weatherapplogotransparent1Icon}
        resizeMode="cover"
        source={require("../assets/weatherapplogotransparent-1.png")}
      />
      <Pressable
        style={styles.arrow}
        onPress={() => navigation.navigate("DayHomePage")}
      >
        <Image
          style={[styles.icon, styles.iconLayout]}
          resizeMode="cover"
          source={require("../assets/arrow4.png")}
        />
      </Pressable>
    </View>
  );
};

const styles = StyleSheet.create({
  iconLayout: {
    overflow: "hidden",
    width: "100%",
  },
  icon: {
    height: "100%",
  },
  x: {
    left: 320,
    top: 6,
    width: 40,
    height: 40,
    position: "absolute",
  },
  faqWindowChild: {
    top: 68,
    left: 29,
    borderRadius: 25,
    backgroundColor: Color.white,
    width: 302,
    height: 423,
    position: "absolute",
  },
  weatherapplogotransparent1Icon: {
    top: 563,
    left: 110,
    width: 140,
    height: 140,
    position: "absolute",
  },
  arrow: {
    left: 15,
    top: 12,
    width: 28,
    height: 23,
    position: "absolute",
  },
  faqWindow: {
    backgroundColor: Color.gainsboro_100,
    flex: 1,
    height: 800,
  },
});

export default FAQWindow;
