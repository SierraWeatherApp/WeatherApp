import * as React from "react";
import { StyleSheet, View, Text } from "react-native";
import { Border, FontFamily, FontSize, Color } from "../GlobalStyles";

const ChangeTemperature = () => {
  return (
    <View style={styles.changeTemperature}>
      <View style={[styles.editCity, styles.editLayout1]}>
        <View style={[styles.editCityChild, styles.editPosition]} />
        <Text style={[styles.celsius, styles.celsiusTypo]}>Celsius</Text>
      </View>
      <View style={[styles.editCity1, styles.editLayout]}>
        <View style={[styles.editCityItem, styles.editLayout]} />
        <Text style={[styles.chooseYourTemperature, styles.celsiusTypo]}>
          Choose Your Temperature
        </Text>
      </View>
      <View style={[styles.editCity2, styles.editLayout1]}>
        <View style={[styles.editCityChild, styles.editPosition]} />
        <Text style={[styles.fahrenheit, styles.celsiusTypo]}>Fahrenheit</Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  editLayout1: {
    height: 31,
    width: 116,
    position: "absolute",
  },
  editPosition: {
    borderRadius: Border.br_4xs,
    left: 0,
    top: 0,
  },
  celsiusTypo: {
    textAlign: "center",
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_sm,
    top: 7,
    position: "absolute",
  },
  editLayout: {
    height: 32,
    width: 319,
    position: "absolute",
  },
  editCityChild: {
    backgroundColor: Color.lightskyblue,
    height: 31,
    width: 116,
    position: "absolute",
    left: 0,
    top: 0,
  },
  celsius: {
    left: 34,
    color: Color.white,
    textAlign: "center",
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_sm,
    top: 7,
  },
  editCity: {
    top: 174,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 122,
    width: 116,
    position: "absolute",
  },
  editCityItem: {
    backgroundColor: Color.white,
    borderRadius: Border.br_4xs,
    left: 0,
    top: 0,
  },
  chooseYourTemperature: {
    left: 55,
    color: Color.black,
    width: 208,
    height: 18,
    textAlign: "center",
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_sm,
    top: 7,
  },
  editCity1: {
    top: 28,
    left: 21,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
  },
  fahrenheit: {
    left: 20,
    color: Color.white,
    textAlign: "center",
    fontFamily: FontFamily.heading1Medium,
    fontSize: FontSize.size_sm,
    top: 7,
  },
  editCity2: {
    top: 270,
    shadowOpacity: 1,
    elevation: 4,
    shadowRadius: 4,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowColor: "rgba(0, 0, 0, 0.25)",
    left: 122,
    width: 116,
    position: "absolute",
  },
  changeTemperature: {
    backgroundColor: Color.gainsboro_100,
    flex: 1,
    width: "100%",
    height: 800,
    overflow: "hidden",
  },
});

export default ChangeTemperature;
